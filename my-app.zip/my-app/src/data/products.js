export const products = [
  {
    id: 1,
    title: "product 1",
    price: 100,
    img: "https://images.pexels.com/photos/6764952/pexels-photo-6764952.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 2,
    title: "product 2",
    price: 200,
    img: "https://images.pexels.com/photos/7583935/pexels-photo-7583935.jpeg?auto=compress&cs=tinysrgb&w=600",
  },
  {
    id: 3,
    title: "product 3",
    price: 300,
    img: "https://images.pexels.com/photos/1229456/pexels-photo-1229456.jpeg?auto=compress&cs=tinysrgb&w=600",
  },
  {
    id: 4,
    title: "product 4",
    price: 400,
    img: "https://images.pexels.com/photos/3954401/pexels-photo-3954401.jpeg?auto=compress&cs=tinysrgb&w=600",
  },
  {
    id: 5,
    title: "product 4",
    price: 500,
    img: "https://images.pexels.com/photos/1191109/pexels-photo-1191109.jpeg?auto=compress&cs=tinysrgb&w=600",
  },
  {
    id: 6,
    title: "product 4",
    price: 600,
    img: "https://images.pexels.com/photos/100582/pexels-photo-100582.jpeg?auto=compress&cs=tinysrgb&w=600",
  },
];
